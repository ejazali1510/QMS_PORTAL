from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
import os

db = SQLAlchemy()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY','dev-secret-key')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL','sqlite:///qms.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'

    from app.routes.auth import auth_bp
    from app.routes.main import main_bp
    from app.routes.import_excel import import_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(import_bp)

    with app.app_context():
        from app import models
        from app.models import User
        db.create_all()

        # Create default admin
        if not User.query.filter_by(username='admin').first():
            admin = User(username='admin', role='manager')
            admin.set_password('admin123')
            db.session.add(admin)

        # Create default auditor
        if not User.query.filter_by(username='auditor').first():
            auditor = User(username='auditor', role='auditor')
            auditor.set_password('audit123')
            db.session.add(auditor)

        db.session.commit()

    return app
