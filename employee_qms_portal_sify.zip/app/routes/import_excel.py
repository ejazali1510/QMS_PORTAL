from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app.models import db, Employee, FormItem
import pandas as pd, os
from werkzeug.utils import secure_filename

import_bp = Blueprint('import', __name__)

ALLOWED = {'xls', 'xlsx'}

def allowed(filename):
    return filename.split('.')[-1].lower() in ALLOWED

@import_bp.route('/import', methods=['GET','POST'])
@login_required
def import_page():
    if current_user.role not in ['auditor', 'manager']:
        flash('Unauthorized', 'danger')
        return redirect(url_for('main.index'))

    if request.method == 'POST':
        file = request.files.get('excel')
        if not file or not allowed(file.filename):
            flash('Invalid file', 'danger')
            return redirect(request.url)

        os.makedirs('uploads', exist_ok=True)
        path = os.path.join('uploads', secure_filename(file.filename))
        file.save(path)

        wb = pd.ExcelFile(path)
        df_emp = wb.parse('employees') if 'employees' in wb.sheet_names else wb.parse(wb.sheet_names[0])
        df_form = wb.parse('form') if 'form' in wb.sheet_names else wb.parse(wb.sheet_names[-1])

        for _, r in df_emp.iterrows():
            code = str(r.get('emp_code') or r.get('employee_code') or '')
            name = r.get('name') or r.get('Name')
            team = r.get('team') or r.get('Team') or 'HELPDESK'
            designation = r.get('designation') or r.get('Designation') or ''
            if not code or not name: continue
            e = Employee.query.filter_by(emp_code=code).first()
            if not e:
                db.session.add(Employee(emp_code=code, name=name, team=team, designation=designation))
            else:
                e.name = name; e.team = team; e.designation = designation
        db.session.commit()

        FormItem.query.delete()
        seq = 0
        for _, r in df_form.iterrows():
            param = r.get('Parameters Evaluation') or r.get('Parameter') or r.get('parameter')
            weight = r.get('Weightage') or r.get('weightage') or 0
            if pd.isna(param): continue
            db.session.add(FormItem(parameter=str(param), weightage=float(weight), sequence=seq))
            seq += 1
        db.session.commit()

        os.remove(path)
        flash('Imported successfully', 'success')
        return redirect(url_for('main.index'))

    return render_template('import.html')
