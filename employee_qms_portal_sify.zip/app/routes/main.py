from flask import Blueprint, render_template, request
from flask_login import login_required, current_user
from app.models import Employee, AuditEntry, AuditDetail

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
@login_required
def index():
    # compute counts for teams
    teams = ['NSE','FORUM','HELPDESK','DSE']
    counts = {t: Employee.query.filter_by(team=t).count() for t in teams}
    return render_template('index.html', counts=counts, teams=teams, user=current_user)

@main_bp.route('/team/<team>')
@login_required
def team_view(team):
    q = request.args.get('q','').strip()
    if q:
        employees = Employee.query.filter(Employee.team==team, Employee.name.ilike(f'%{q}%')).all()
    else:
        employees = Employee.query.filter_by(team=team).all()
    return render_template('team.html', team_name=team, employees=employees, query=q)

@main_bp.route('/employee/<int:id>')
@login_required
def employee_view(id):
    emp = Employee.query.get_or_404(id)
    audit = AuditEntry.query.filter_by(employee_id=emp.id).order_by(AuditEntry.created_at.desc()).first()
    if audit:
        audit.details = AuditDetail.query.filter_by(audit_id=audit.id).all()
    return render_template('employee.html', emp=emp, audit=audit)
