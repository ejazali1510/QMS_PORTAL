from app import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
import datetime

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True)
    password_hash = db.Column(db.String(200))
    role = db.Column(db.String(50))

    def set_password(self, p):
        self.password_hash = generate_password_hash(p)

    def check_password(self, p):
        return check_password_hash(self.password_hash, p)

@login_manager.user_loader
def load_user(uid):
    return User.query.get(int(uid))

class Employee(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    emp_code = db.Column(db.String(50), unique=True)
    name = db.Column(db.String(200))
    team = db.Column(db.String(50))
    designation = db.Column(db.String(200))

class FormItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    parameter = db.Column(db.String(500))
    weightage = db.Column(db.Float)
    sequence = db.Column(db.Integer)

class AuditEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey('employee.id'))
    auditor_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    auditor_name = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    total_score = db.Column(db.Float)
    details = db.relationship('AuditDetail', backref='audit', cascade='all, delete-orphan')

class AuditDetail(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    audit_id = db.Column(db.Integer, db.ForeignKey('audit_entry.id'))
    parameter = db.Column(db.String(500))
    weightage = db.Column(db.Float)
    achieved = db.Column(db.Float)
    remark = db.Column(db.String(1000))
